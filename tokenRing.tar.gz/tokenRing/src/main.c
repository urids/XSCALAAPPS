
/*
 * Token Ring Basic Example
 * */
#include "common.h"
#include "unistd.h"

int i,j; //indexExclusive variables
int err;

#define TRAY_0 0
#define TASK0 0

#define TRAY_1 1
#define TASK1 1

#define TRAY_2 2
#define TASK2 2

#define TASK3 3
#define TASK4 4

#define TAG0 0
#define TAG1 1
#define TAG2 2
#define TAG3 3
#define TAG4 4
#define TAG5 5

int main(int argc, char** argv){
	int devKind;
	char* infArg;
	//infArg = strtok(argv[5], "=");
	//infArg = strtok(NULL, "= ");
	devKind = 0 ;//atoi(infArg);

	int res=0;

	int provided;
	MPI_Init_thread(&argc,&argv, MPI_THREAD_MULTIPLE, &provided);

	//MPI_Init(&argc,&argv);
	int taskId;

	int Dims = 1;
	size_t globalDims[1] = {numThreads};
	size_t localDims[1] = {numThreads};

	int myRank;
	MPI_Comm_rank(MPI_COMM_WORLD,&myRank);
	//task_t myTasks[5];
	task_t* myTasks=malloc(5*sizeof(task_t));
	int numTasks;

	XSCALA_InitTasks(argc,argv,&myTasks, 5);

	XSCALA_getNumTasks(&numTasks, MPI_COMM_WORLD);
	//int numTasks=OMPI_CollectTaskInfo(devKind, MPI_COMM_WORLD);

	//XSCALA_Init(argc, argv);

	printf("numTasks: %d\n",numTasks);

	for (taskId = 0; taskId < numTasks; taskId++) {
		err |= OMPI_XclMallocTray(taskId, TRAY_0, sizeof(int),MPI_COMM_WORLD);
		err |= OMPI_XclSetProcedure(MPI_COMM_WORLD,taskId,"/home/uriel/Dev/mpiApps/extnsApps/tokenRing/src/proc.cl","Accum");
	}


	int te=0;
	err |= OMPI_XclWriteTray(TASK0, TRAY_0, sizeof(int),&te,MPI_COMM_WORLD);
	err |= OMPI_XclWriteTray(TASK2, TRAY_0, sizeof(int),&te,MPI_COMM_WORLD);


	//err |= OMPI_XclMallocTray(TASK4, TRAY_0, sizeof(int),MPI_COMM_WORLD);
	err |= OMPI_XclMallocTray(TASK4, TRAY_1, sizeof(int),MPI_COMM_WORLD);
	err |= OMPI_XclMallocTray(TASK4, TRAY_2, sizeof(int),MPI_COMM_WORLD);
	err |= OMPI_XclSetProcedure(MPI_COMM_WORLD,TASK4,"/home/uriel/Dev/mpiApps/extnsApps/tokenRing/src/proc.cl","Sum");

		err |= OMPI_XclExecTask(MPI_COMM_WORLD, TASK0, Dims, globalDims, localDims, "%T, %d", TRAY_0, TASK0);

		err |= OMPI_XclSendRecv(TASK0, TRAY_0, TASK1, TRAY_0, sizeof(int), 9);

	//	err |= OMPI_XclSendRecv(TASK1, TRAY_0, TASK0, TRAY_0, sizeof(int), 4);

		err |= OMPI_XclExecTask(MPI_COMM_WORLD, TASK1, Dims, globalDims, localDims, "%T, %d", TRAY_0, TASK1);

		err = OMPI_XclExecTask(MPI_COMM_WORLD, TASK2, Dims, globalDims, localDims, "%T, %d", TRAY_0, TASK2);

		err |= OMPI_XclSendRecv(TASK2, TRAY_0, TASK3, TRAY_0, sizeof(int), 7);

		//err = OMPI_XclWaitFor(1, (int[]){TASK0}, MPI_COMM_WORLD);


/*		if(myRank==0){
			err |= OMPI_XclReadTray(TASK3, TRAY_0, sizeof(int), &res, MPI_COMM_WORLD);
		}
		err = OMPI_XclWaitFor(1, (int[]){TASK3}, MPI_COMM_WORLD);
		if(myRank==0){
			printf("\n res: %d \n", res);
		}*/



		err |= OMPI_XclExecTask(MPI_COMM_WORLD, TASK3, Dims, globalDims,localDims, "%T, %d", TRAY_0,TASK3);

		err |= OMPI_XclSendRecv(TASK1, TRAY_0, TASK4, TRAY_0, sizeof(int), TAG2);


//		err = OMPI_XclWaitFor(1, &(int){TASK4}, MPI_COMM_WORLD);


		err |= OMPI_XclSendRecv(TASK3, TRAY_0, TASK4, TRAY_1, sizeof(int), TAG3);
			err = OMPI_XclWaitFor(1, &(int){TASK4}, MPI_COMM_WORLD);
		err |= OMPI_XclExecTask(MPI_COMM_WORLD, TASK4, Dims, globalDims,localDims, "%T, %T, %T", TRAY_2,TRAY_0,TRAY_1);

		//if(myRank==0){
			err |= OMPI_XclReadTray(TASK4, TRAY_2, sizeof(int), &res, MPI_COMM_WORLD);
		//}
		err = OMPI_XclWaitFor(1, (int[]){TASK4}, MPI_COMM_WORLD);
		//if(myRank==0){
			printf("\n res: %d \n", res);
		//}

	MPI_Finalize();
return 0;
}
