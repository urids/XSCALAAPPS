/*
 * common.h
 *
 *  Created on: Aug 31, 2015
 *      Author: uriel
 */

#ifndef COMMON_H_
#define COMMON_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "mpi.h"

typedef struct entityType_st{
	float P[4];
	float V[3];
	float nP[4];
	float nV[3];
}entityType;

#define mymod(n,m) ((n % m) + m) % m;
int i,j; //indexExclusive variables
#define numThreads 10

#endif /* COMMON_H_ */
